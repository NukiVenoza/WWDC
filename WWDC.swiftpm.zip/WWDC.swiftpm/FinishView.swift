//
//  FinishView.swift
//  WWDC
//
//  Created by Nuki Venoza on 10/04/23.
//

import SwiftUI

struct FinishView: View {
    var body: some View {
        ZStack{
            VStack{
                HStack{
                    VStack{
                        Image("medal")
                            .resizable()
                            .frame(width: 180, height: 246, alignment: .bottom)
                        
                        Text("Congratulations!")
                            .font(Font.custom("LLPixel", size: 48))
                            .foregroundColor(Color(red: 171 / 255, green: 59 / 255, blue: 97 / 255, opacity: 100.0))
                            .fontWeight(.bold)
                    }
                }
                .padding(.bottom, 100)
                
                HStack{
                    VStack{
                        Text("Nice! You have successfuly learn how to manage waste to save the environment")
                            .multilineTextAlignment(.leading)
                            .font(Font.custom("LLPixel", size: 36))
                            .frame(width: 769.0, height: 274.0)
                            .foregroundColor(Color(red: 18 / 255, green: 60 / 255, blue: 106 / 255, opacity: 100.0))
                        
                        HStack{
                            Spacer()
                            NavigationLink(destination: ContentView()){
                                Image("arrow")
                                    .resizable()
                                    .frame(width: 66.0, height: 36.0)
                                    .padding(.trailing, 50)
                                    .padding(.bottom, 40)
                            }
                            
                        }
                            
                    }
                }
                .background(Color(red: 237 / 255, green: 200 / 255, blue: 184 / 255, opacity: 100.0))
                .cornerRadius(25.0)
                .padding()
                .padding(.bottom, -200)
                
            }
            
            
        }
        .navigationBarBackButtonHidden()
        .background(
            Image("bgImage")
                .resizable()
                .edgesIgnoringSafeArea(.all)
                .frame(width: UIScreen.main.bounds.width, height: UIScreen.main.bounds.height)

        )
        .background(
            Color(red: 237.0 / 255, green: 226.0 / 255, blue: 220.0 / 255, opacity: 100.0)
                .ignoresSafeArea()
        )
        
    }
}

struct FinishView_Previews: PreviewProvider {
    static var previews: some View {
        FinishView()
    }
}
