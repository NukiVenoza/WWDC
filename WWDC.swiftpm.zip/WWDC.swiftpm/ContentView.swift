//Made by Nuki Venoza

import SwiftUI

public struct generateCustomFont {

    public static func registerFonts() {
            registerFont(bundle: Bundle.main, fontName: "LLPIXEL3", fontExtension: ".ttf")
        }

    fileprivate static func registerFont(bundle: Bundle, fontName: String, fontExtension: String) {
         guard let fontURL = bundle.url(forResource: fontName, withExtension: fontExtension),
               let fontDataProvider = CGDataProvider(url: fontURL as CFURL),
               let font = CGFont(fontDataProvider) else {
             fatalError("Couldn't create font from data")
         }

         var error: Unmanaged<CFError>?
         CTFontManagerRegisterGraphicsFont(font, &error)
     }
}

struct ContentView: View {
    
    @State private var font: Font?
    @State var audioPlayer = PlayMusic.shared

    var body: some View {
        
        NavigationView {
            ZStack{
                Color(red: 237.0 / 255, green: 226.0 / 255, blue: 220.0 / 255, opacity: 100.0)
                    .ignoresSafeArea()
                
                VStack {
                    HStack{
                        Image("cloud")
                            .resizable()
                            .frame(width: 226, height: 121, alignment: .bottom)
                            .padding(.bottom, 100)
                            .padding(.leading, 50)
                        Spacer()
                    }
                    
                    Text("Manage")
                        .font(Font.custom("LLPixel", size: 60))
                        .foregroundColor(Color(red: 171 / 255, green: 59 / 255, blue: 97 / 255, opacity: 100.0))
                    
                    Text("Your")
                        .font(Font.custom("LLPixel", size: 60))
                        .foregroundColor(Color(red: 171 / 255, green: 59 / 255, blue: 97 / 255, opacity: 100.0))
                    
                    Text("Waste")
                        .font(Font.custom("LLPixel", size: 60))
                        .foregroundColor(Color(red: 171 / 255, green: 59 / 255, blue: 97 / 255, opacity: 100.0))
                    
                    NavigationLink(destination: DialogView()){
                        Text("Start")
                            .padding(30)
                            .font(Font.custom("LLPixel", size: 36))
                            .background(Color(red: 237 / 255, green: 200 / 255, blue: 184 / 255, opacity: 100.0))
                            .foregroundColor(Color(red: 171 / 255, green: 59 / 255, blue: 97 / 255, opacity: 100.0))
                            .cornerRadius(8)
                    }
                    .padding(.top, 50)
                    .frame(maxWidth: 197, maxHeight: 89)
                                    
                    HStack{
                        Spacer()

                        Image("cloud")
                            .resizable()
                            .frame(width: 226, height: 121, alignment: .bottom)
                            .padding(.top, 100)
                            .padding(.trailing, 50)
                    }
                    
                    

                }
            }
            
            
        }
        .onAppear {
            audioPlayer.play()
        }
        .onDisappear {
            audioPlayer.stop()
        }
        .navigationViewStyle(StackNavigationViewStyle())
        .navigationBarBackButtonHidden()
        
    }
        
}


