//
//  DialogView.swift
//  WWDC
//
//  Created by Nuki Venoza on 09/04/23.
//

import SwiftUI

struct DialogView: View {
    var body: some View {
        ZStack{
            Color(red: 237.0 / 255, green: 226.0 / 255, blue: 220.0 / 255, opacity: 100.0)
                .ignoresSafeArea()
            
            VStack{
                HStack{
                    VStack{
                        Image("cloud")
                            .resizable()
                            .frame(width: 190, height: 102, alignment: .bottom)
                            .padding(.trailing, 180)
                        
                        Image("waveMemoji")
                            .resizable()
                            .frame(width: 215.0, height: 215.0)
                            .padding(.top, 200)
                            .padding(.bottom, -100)
                            .padding(.trailing, 220)

                    }
                    VStack{
                        Image("cloud")
                            .resizable()
                            .frame(width: 269, height: 144, alignment: .bottom)
                            .padding(.bottom, 40)
                        
                        Image("tree")
                            .resizable()
                            .frame(width: 276, height: 422)
                            .padding(.bottom, -40)
                    }
                                       

                }
                
                HStack{
                    VStack{
                        Text("Hi, my name is Nuki, welcome to “Manage Your Waste”. I will teach you a lot of new things about waste management.")
                            .multilineTextAlignment(.leading)
                            .font(Font.custom("LLPixel", size: 36))
                            .frame(width: 769.0, height: 274.0)
                            .foregroundColor(Color(red: 18 / 255, green: 60 / 255, blue: 106 / 255, opacity: 100.0))
                            
                        HStack{
                            Spacer()
                            NavigationLink(destination: FactsView()){
                                Image("arrow")
                                    .resizable()
                                    .frame(width: 66.0, height: 36.0)
                                    .padding(.trailing, 50)
                                    .padding(.bottom, 40)
                            }
                            
                        }
                            
                    }

                }
                .background(Color(red: 237 / 255, green: 200 / 255, blue: 184 / 255, opacity: 100.0))
                .cornerRadius(25.0)
                .padding()
                
                
            }
        }
        .navigationBarBackButtonHidden()
        
    }
}

struct DialogView_Previews: PreviewProvider {
    static var previews: some View {
        DialogView()
    }
}
