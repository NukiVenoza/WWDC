//
//  Facts2View.swift
//  WWDC
//
//  Created by Nuki Venoza on 15/04/23.
//

import SwiftUI

struct Facts2View: View {
    var body: some View {
        ZStack{
            
            VStack{
                HStack{
                    Image("contamination")
                        .resizable()
                        .frame(width: 650, height: 364, alignment: .bottom)
                    
                }
                .padding()
                .padding(.top, 200)
                
                HStack{
                    Image("presentMemoji")
                        .resizable()
                        .frame(width: 214, height: 207)
                        .padding(.leading, 70)
                        .padding(.bottom, -25)
                    
                    Spacer()
                    
                }
                .padding(.top, 50)
                
                HStack{
                    VStack{
                        Text("Waste Management is important as it saves the environment from the toxic effects in waste as shown above. It could prevent water contamination, soil erosion, and air contamination.")
                            .multilineTextAlignment(.leading)
                            .font(Font.custom("LLPixel", size: 36))
                            .frame(width: 769.0, height: 274.0)
                            .foregroundColor(Color(red: 18 / 255, green: 60 / 255, blue: 106 / 255, opacity: 100.0))
                        
                        HStack{
                            Spacer()
                            NavigationLink(destination: CleanTrashView()){
                                Image("arrow")
                                    .resizable()
                                    .frame(width: 66.0, height: 36.0)
                                    .padding(.trailing, 50)
                                    .padding(.bottom, 40)
                            }
                            
                        }
                        
                    }
                }
                .background(Color(red: 237 / 255, green: 200 / 255, blue: 184 / 255, opacity: 100.0))
                .cornerRadius(25.0)
                .padding()
                .padding(.bottom, 150)
            }
            
            
        }
        .navigationBarBackButtonHidden()
        .background(
            Image("bgImage")
                .resizable()
                .edgesIgnoringSafeArea(.all)
                .frame(width: UIScreen.main.bounds.width, height: UIScreen.main.bounds.height)

        )
        .background(
            Color(red: 237.0 / 255, green: 226.0 / 255, blue: 220.0 / 255, opacity: 100.0)
                .ignoresSafeArea()
        )
        
    }
}

struct Facts2View_Previews: PreviewProvider {
    static var previews: some View {
        Facts2View()
    }
}
