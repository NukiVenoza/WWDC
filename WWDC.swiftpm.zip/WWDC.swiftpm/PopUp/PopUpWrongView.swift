//
//  PopUpWrongView.swift
//  WWDC
//
//  Created by Nuki Venoza on 13/04/23.
//

import SwiftUI

struct PopUpWrongView: View {
    
    var title: String
    var buttonName: String
    
    @Binding var show: Bool
    
    var body: some View {
        
        ZStack {
            if show {
                Color.black.opacity(show ? 0.5 : 0).edgesIgnoringSafeArea(.all)
                
                VStack(alignment: .center, spacing: 0) {
                    Text(title)
                        .frame(maxWidth: .infinity)
                        .frame(height: 45, alignment: .center)
                        .font(Font.custom("LLPixel", size: 36))
                        .foregroundColor(Color(red: 18 / 255, green: 60 / 255, blue: 106 / 255, opacity: 100.0))
                        .padding(.bottom, 30)
                    
                    NavigationLink(destination: ManageTrashView()){
                        Text(buttonName)
                            .padding(30)
                            .font(Font.custom("LLPixel", size: 24))
                            .background(Color(red: 171 / 255, green: 59 / 255, blue: 97 / 255, opacity: 100.0))
                            .foregroundColor(Color(red: 237 / 255, green: 226 / 255, blue: 220 / 255, opacity: 100.0))
                            .cornerRadius(8)
                    }
                    .padding(.top, 50)
                    .frame(maxWidth: 276, maxHeight: 83)
                    
                }
                .frame(maxWidth: 600, maxHeight: 300)
                .background(Color(red: 237 / 255, green: 200 / 255, blue: 184 / 255, opacity: 100.0))
                .cornerRadius(25)
                
            }
        }
    }
}

struct PopUpWrongView_Previews: PreviewProvider {
    static var previews: some View {
        PopUpWrongView(title: "Wrong Trash Can!", buttonName: "Try Again", show: .constant(true))
    }
}
