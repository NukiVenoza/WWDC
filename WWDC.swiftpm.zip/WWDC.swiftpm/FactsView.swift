//
//  FactsView.swift
//  WWDC
//
//  Created by Nuki Venoza on 10/04/23.
//

import SwiftUI

struct FactsView: View {
    var body: some View {
        ZStack{
            
            VStack{
                HStack{
                    Image("earth")
                        .resizable()
                        .frame(width: 235, height: 235, alignment: .bottom)
                        .padding(.leading, 30)
                    
                    Spacer()
                    
                    Text("2.01 billion of waste / year")
                        .font(Font.custom("LLPixel", size: 36))
                        .foregroundColor(Color(red: 18 / 255, green: 60 / 255, blue: 108 / 255, opacity: 100.0))
                        .padding(.trailing, 4)
                    
                }
                .padding()
                .padding(.top, 200)
                
                HStack{
                    Image("presentMemoji")
                        .resizable()
                        .frame(width: 214, height: 207)
                        .padding(.leading, 70)
                        .padding(.bottom, -25)
                    
                    Spacer()
                    
                }
                .padding(.top, 50)
                
                HStack{
                    VStack{
                        Text("Did you know that there is approximately 33% waste in this world that is not managed in an environmentally safe way.")
                            .multilineTextAlignment(.leading)
                            .font(Font.custom("LLPixel", size: 36))
                            .frame(width: 769.0, height: 274.0)
                            .foregroundColor(Color(red: 18 / 255, green: 60 / 255, blue: 106 / 255, opacity: 100.0))
                        
                        HStack{
                            Spacer()
                            NavigationLink(destination: Facts2View()){
                                Image("arrow")
                                    .resizable()
                                    .frame(width: 66.0, height: 36.0)
                                    .padding(.trailing, 50)
                                    .padding(.bottom, 40)
                            }
                            
                        }
                        
                    }
                }
                .background(Color(red: 237 / 255, green: 200 / 255, blue: 184 / 255, opacity: 100.0))
                .cornerRadius(25.0)
                .padding()
                .padding(.bottom, 100)
            }
            
            
        }
        .navigationBarBackButtonHidden()
        .background(
            Image("bgImage")
                .resizable()
                .edgesIgnoringSafeArea(.all)
                .frame(width: UIScreen.main.bounds.width, height: UIScreen.main.bounds.height)

        )
        .background(
            Color(red: 237.0 / 255, green: 226.0 / 255, blue: 220.0 / 255, opacity: 100.0)
                .ignoresSafeArea()
        )
    }
}


struct FactsView_Previews: PreviewProvider {
    static var previews: some View {
        FactsView()
    }
}
