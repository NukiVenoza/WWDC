//
//  CleanTrashView.swift
//  WWDC
//
//  Created by Nuki Venoza on 10/04/23.
//

import SwiftUI

struct CleanTrashView: View {
    
    @State var imageOpacity = 1.0
    @State var arrowOpacity = 0.0
    @State var tapOpacity = 1.0
    @State var scale = 1.0

    var body: some View {
        ZStack{
            
            Image("tap")
                .resizable()
                .frame(width: 146, height: 159, alignment: .bottom)
                .position(x: 620, y: 560)
                .opacity(tapOpacity)
            
            VStack{
                Text("Now, let’s clean all the trash. Tap the pile of trash to clean all the waste!")
                    .multilineTextAlignment(.center)
                    .font(Font.custom("LLPixel", size: 48))
                    .foregroundColor(Color(red: 171 / 255, green: 59 / 255, blue: 97 / 255, opacity: 100.0))
                    .frame(width: 665)
                    .padding(.top, 100)
                
                Button {
                    imageOpacity = 0.0
                    arrowOpacity = 1.0
                    tapOpacity = 0.0
                } label: {
                    Image("trashPile")
                        .resizable()
                        .frame(width: 465, height: 403)
                        .padding(.top, 80)
                    
                }.opacity(imageOpacity)
                
                NavigationLink(destination: ManageTrainingView()){
                    Image("arrow")
                        .resizable()
                        .frame(width: 66.0, height: 36.0)
                        .padding(.leading, 570)
                        .padding(.top, 80)
                        .opacity(arrowOpacity)
 
                }
            }
            .padding()
            
        }
        .navigationBarBackButtonHidden()
        .background(
            Image("bgImage")
                .resizable()
                .edgesIgnoringSafeArea(.all)
                .frame(width: UIScreen.main.bounds.width, height: UIScreen.main.bounds.height)

        )
        .background(
            Color(red: 237.0 / 255, green: 226.0 / 255, blue: 220.0 / 255, opacity: 100.0)
                .ignoresSafeArea()
        )
    }

}

struct CleanTrashView_Previews: PreviewProvider {
    static var previews: some View {
        CleanTrashView()
    }
}
