//
//  ManageTrainingView.swift
//  WWDC
//
//  Created by Nuki Venoza on 10/04/23.
//

import SwiftUI

struct ManageTrainingView: View {
    @State var xPlasticCan: CGFloat = 120
    @State var yPlasticCan: CGFloat = 400
    
    @State var xPlasticBag: CGFloat = 400
    @State var yPlasticBag: CGFloat = 550
    
    @State var xOthersCan: CGFloat = 400
    @State var yOthersCan: CGFloat = 200
    
    @State var xPaperCan: CGFloat = 700
    @State var yPaperCan: CGFloat = 400
    
    @State var collision: Bool = false
    
    @State var plasticOpacity = 1.0
    @State var arrowOpacity = 0.0
    
    @State private var showPopUpWrong: Bool = false
    @State private var showPopUpWin: Bool = false

    var body: some View {
        ZStack {
            ZStack{
                
                Image("plasticCan")
                    .resizable()
                    .frame(width: 127, height: 237, alignment: .bottom)
                    .position(x: self.xPlasticCan, y: self.yPlasticCan)
                
                
                Image("othersCan")
                    .resizable()
                    .frame(width: 127, height: 237, alignment: .bottom)
                    .position(x: self.xOthersCan, y: self.yOthersCan)
                
                Image("plasticBag")
                    .resizable()
                    .frame(width: 165, height: 165, alignment: .bottom)
                    .position(x: self.xPlasticBag, y: self.yPlasticBag)
                    .gesture(
                        DragGesture()
                            .onChanged({ value in
                                
                                self.xPlasticBag = value.location.x
                                self.yPlasticBag = value.location.y
                                
                                self.detectCollision()
                            })
                    )
                    .opacity(plasticOpacity)
                
                Image("paperCan")
                    .resizable()
                    .frame(width: 127, height: 237, alignment: .bottom)
                    .position(x: self.xPaperCan, y: self.yPaperCan)
                
                VStack{
                    
                    HStack{
                        Image("presentMemoji2")
                            .resizable()
                            .frame(width: 214, height: 207)
                            .padding(.leading, 30)
                            .padding(.top, 500)
                            .padding(.bottom, -25)
                        
                        Spacer()
                    }
                    
                    HStack{
                        VStack{
                            Text("Now, lets try to manage your own waste. Drag the plastic bag to the plastic trash can.")
                                .multilineTextAlignment(.leading)
                                .font(Font.custom("LLPixel", size: 36))
                                .frame(width: 769.0, height: 274.0)
                                .foregroundColor(Color(red: 18 / 255, green: 60 / 255, blue: 106 / 255, opacity: 100.0))
                            
                            HStack{
                                Spacer()
                                NavigationLink(destination: ManageTrashView()){
                                    Image("arrow")
                                        .resizable()
                                        .frame(width: 66.0, height: 36.0)
                                        .padding(.trailing, 50)
                                        .padding(.bottom, 40)
                                        .opacity(arrowOpacity)

                                }
                                
                            }
                            
                        }
                    }
                    .background(Color(red: 237 / 255, green: 200 / 255, blue: 184 / 255, opacity: 100.0))
                    .cornerRadius(25.0)
                    .padding()
                }
                
                
            }
            .navigationBarBackButtonHidden()
            .background(
                Image("bgImage")
                    .resizable()
                    .edgesIgnoringSafeArea(.all)
                    .frame(width: UIScreen.main.bounds.width, height: UIScreen.main.bounds.height)

            )
            .background(
                Color(red: 237.0 / 255, green: 226.0 / 255, blue: 220.0 / 255, opacity: 100.0)
                    .ignoresSafeArea()
            )
            
            PopUpWrongTrainingView(title: "Wrong Trash Can!", buttonName: "Try Again", show: $showPopUpWrong)

            PopUpWinTrainingView(title: "Nice!", buttonName: "Next", show: $showPopUpWin)
        }
    }

    func detectCollision() {
        if abs(self.xPlasticCan - self.xPlasticBag) < 127  && abs(self.yPlasticCan - self.yPlasticBag) < 237 {
            self.collision = true
            plasticOpacity = 0.0
            arrowOpacity = 1.0
            
            showPopUpWin = true
            
        } else if abs(self.xOthersCan - self.xPlasticBag) < 127  && abs(self.yOthersCan - self.yPlasticBag) < 237{
            self.collision = false
            plasticOpacity = 0.0

            showPopUpWrong = true
            
        } else if abs(self.xPaperCan - self.xPlasticBag) < 127  && abs(self.yPaperCan - self.yPlasticBag) < 237{
            self.collision = false
            plasticOpacity = 0.0

            showPopUpWrong = true

        }
    }
    
}

struct ManageTrainingView_Previews: PreviewProvider {
    static var previews: some View {
        ManageTrainingView()
    }
}
