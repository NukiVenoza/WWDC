//
//  ManageTrashView.swift
//  WWDC
//
//  Created by Nuki Venoza on 10/04/23.
//

import SwiftUI

struct ManageTrashView: View {
    
    @State var xPlasticCan: CGFloat = 120
    @State var yPlasticCan: CGFloat = 400
    
    @State var xPlasticBag: CGFloat = 400
    @State var yPlasticBag: CGFloat = 550
    
    @State var xOthersCan: CGFloat = 400
    @State var yOthersCan: CGFloat = 200
    
    @State var xPaperCan: CGFloat = 700
    @State var yPaperCan: CGFloat = 400
    
    @State var xRandom1: CGFloat = 400
    @State var yRandom1: CGFloat = 500
    
    @State var xRandom2: CGFloat = 450
    @State var yRandom2: CGFloat = 550
    
    @State var xRandom3: CGFloat = 350
    @State var yRandom3: CGFloat = 550
    
    @State var xRandom4: CGFloat = 400
    @State var yRandom4: CGFloat = 600
    
    @State var collision: Bool = false
    
    @State var collisionConfirm1: Bool = false
    @State var collisionConfirm2: Bool = false
    @State var collisionConfirm3: Bool = false
    @State var collisionConfirm4: Bool = false
    
    @State var opacity1 = 1.0
    @State var opacity2 = 1.0
    @State var opacity3 = 1.0
    @State var opacity4 = 1.0
        
    @State var arrowOpacity = 0.0
    
    @State private var showPopUpWrong: Bool = false
    @State private var showPopUpWin: Bool = false
    
    var imageArray = ["plasticBag", "paper", "sodaCan", "glassBottle"]
    
    @State var randomIndex1 = Int.random(in: 0..<4)
    @State var randomIndex2 = Int.random(in: 0..<4)
    @State var randomIndex3 = Int.random(in: 0..<4)
    @State var randomIndex4 = Int.random(in: 0..<4)
    
    var body: some View {
        ZStack {
            ZStack{
                
                Image("plasticCan")
                    .resizable()
                    .frame(width: 127, height: 237, alignment: .bottom)
                    .position(x: self.xPlasticCan, y: self.yPlasticCan)
                
                Image("othersCan")
                    .resizable()
                    .frame(width: 127, height: 237, alignment: .bottom)
                    .position(x: self.xOthersCan, y: self.yOthersCan)
                
                Image(imageArray[randomIndex1])
                    .resizable()
                    .aspectRatio(contentMode: .fit)
                    .frame(width: 165, height: 165, alignment: .bottom)
                    .position(x: self.xRandom1, y: self.yRandom1)
                    .gesture(
                        DragGesture()
                            .onChanged({ value in
                                
                                self.xRandom1 = value.location.x
                                self.yRandom1 = value.location.y
                                
                                self.detectCollision(randomIndex: randomIndex1, xCoordinate: xRandom1, yCoordinate: yRandom1, collisionConfirm: &collisionConfirm1, opacity: &opacity1)
                                winConfirm()
                            })
                    )
                    .opacity(opacity1)
                
                Image(imageArray[randomIndex2])
                    .resizable()
                    .aspectRatio(contentMode: .fit)
                    .frame(width: 165, height: 165, alignment: .bottom)
                    .position(x: self.xRandom2, y: self.yRandom2)
                    .gesture(
                        DragGesture()
                            .onChanged({ value in
                                
                                self.xRandom2 = value.location.x
                                self.yRandom2 = value.location.y
                                
                                self.detectCollision(randomIndex: randomIndex2, xCoordinate: xRandom2, yCoordinate: yRandom2, collisionConfirm: &collisionConfirm2, opacity: &opacity2)
                                winConfirm()

                            })
                    )
                    .opacity(opacity2)

                
                Image(imageArray[randomIndex3])
                    .resizable()
                    .aspectRatio(contentMode: .fit)
                    .frame(width: 165, height: 165, alignment: .bottom)
                    .position(x: self.xRandom3, y: self.yRandom3)
                    .gesture(
                        DragGesture()
                            .onChanged({ value in
                                
                                self.xRandom3 = value.location.x
                                self.yRandom3 = value.location.y
                                
                                self.detectCollision(randomIndex: randomIndex3, xCoordinate: xRandom3, yCoordinate: yRandom3, collisionConfirm: &collisionConfirm3, opacity: &opacity3)
                                winConfirm()

                            })
                    )
                    .opacity(opacity3)

                Image(imageArray[randomIndex4])
                    .resizable()
                    .aspectRatio(contentMode: .fit)
                    .frame(width: 165, height: 165, alignment: .bottom)
                    .position(x: self.xRandom4, y: self.yRandom4)
                    .gesture(
                        DragGesture()
                            .onChanged({ value in
                                
                                self.xRandom4 = value.location.x
                                self.yRandom4 = value.location.y
                                
                                self.detectCollision(randomIndex: randomIndex4, xCoordinate: xRandom4, yCoordinate: yRandom4, collisionConfirm: &collisionConfirm4, opacity: &opacity4)
                                winConfirm()

                            })
                    )
                    .opacity(opacity4)
                                
                Image("paperCan")
                    .resizable()
                    .frame(width: 127, height: 237, alignment: .bottom)
                    .position(x: self.xPaperCan, y: self.yPaperCan)
                
                VStack{
                    HStack{
                        Image("presentMemoji2")
                            .resizable()
                            .frame(width: 214, height: 207)
                            .padding(.leading, 30)
                            .padding(.top, 500)
                            .padding(.bottom, -25)
                        
                        Spacer()
                    }
                    
                    HStack{
                        VStack{
                            Text("So, let’s test your waste management skill. Try to manage all of the waste above to the right trash can! (All waste must be placed in the right trash can to win)")
                                .multilineTextAlignment(.leading)
                                .font(Font.custom("LLPixel", size: 36))
                                .frame(width: 769.0, height: 274.0)
                                .foregroundColor(Color(red: 18 / 255, green: 60 / 255, blue: 106 / 255, opacity: 100.0))
                            
                            HStack{
                                Spacer()
                                NavigationLink(destination: FinishView()){
                                    Image("arrow")
                                        .resizable()
                                        .frame(width: 66.0, height: 36.0)
                                        .padding(.trailing, 50)
                                        .padding(.bottom, 40)
                                        .opacity(arrowOpacity)
                                    
                                }
                                
                            }
                            
                        }
                    }
                    .background(Color(red: 237 / 255, green: 200 / 255, blue: 184 / 255, opacity: 100.0))
                    .cornerRadius(25.0)
                    .padding()
                }
                
                
            }
            .navigationBarBackButtonHidden()
            .background(
                Image("bgImage")
                    .resizable()
                    .edgesIgnoringSafeArea(.all)
                    .frame(width: UIScreen.main.bounds.width, height: UIScreen.main.bounds.height)

            )
            .background(
                Color(red: 237.0 / 255, green: 226.0 / 255, blue: 220.0 / 255, opacity: 100.0)
                    .ignoresSafeArea()
            )
            
            PopUpWrongView(title: "Wrong Trash Can!", buttonName: "Try Again", show: $showPopUpWrong)
            
            PopUpWinView(title: "Nice!", buttonName: "Next", show: $showPopUpWin)
        }
        
    }
    
    func detectCollision(randomIndex: Int, xCoordinate: CGFloat, yCoordinate: CGFloat, collisionConfirm: inout Bool, opacity: inout Double) {
        if randomIndex == 0 {
            //plastic
            if abs(self.xPlasticCan - xCoordinate) < 127  && abs(self.yPlasticCan - yCoordinate) < 237 {
                self.collision = true
                
                opacity = 0.0
                collisionConfirm = true
                
            } else if abs(self.xOthersCan - xCoordinate) < 127  && abs(self.yOthersCan - yCoordinate) < 237{
                self.collision = false
                
                opacity = 0.0
                
            } else if abs(self.xPaperCan - xCoordinate) < 127  && abs(self.yPaperCan - yCoordinate) < 237{
                self.collision = false
                
                opacity = 0.0
            }
            
        } else if randomIndex == 1 {
            //paper
            if abs(self.xPaperCan - xCoordinate) < 127  && abs(self.yPaperCan - yCoordinate) < 237 {
                self.collision = true

                opacity = 0.0
                collisionConfirm = true

            } else if abs(self.xOthersCan - xCoordinate) < 127  && abs(self.yOthersCan - yCoordinate) < 237{
                self.collision = false

                opacity = 0.0

            } else if abs(self.xPlasticCan - xCoordinate) < 127  && abs(self.yPlasticCan - yCoordinate) < 237{
                self.collision = false

                opacity = 0.0
            }
            
        } else if randomIndex == 2 || randomIndex == 3{
            //others
            if abs(self.xOthersCan - xCoordinate) < 127  && abs(self.yOthersCan - yCoordinate) < 237 {
                self.collision = true
                
                opacity = 0.0
                collisionConfirm = true

            } else if abs(self.xPaperCan - xCoordinate) < 127  && abs(self.yPaperCan - yCoordinate) < 237{
                self.collision = false

                opacity = 0.0
            } else if abs(self.xPlasticCan - xCoordinate) < 127  && abs(self.yPlasticCan - yCoordinate) < 237{
                self.collision = false

                opacity = 0.0
            }
        }

    }
    
    func winConfirm() {
        if opacity1 == 0.0 && opacity2 == 0.0 && opacity3 == 0.0 && opacity4 == 0.0 {
            if collisionConfirm1 == true && collisionConfirm2 == true && collisionConfirm3 == true && collisionConfirm4 == true {
                arrowOpacity = 1.0
                showPopUpWin = true
            } else {
                
                showPopUpWrong = true
            }
        }
        else {
            return
        }
        
    }
    
}

struct ManageTrashView_Previews: PreviewProvider {
    static var previews: some View {
        ManageTrashView()
    }
}
