import SwiftUI

@main
struct MyApp: App {
    
    init() {
        generateCustomFont.registerFonts()

    }
    
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
